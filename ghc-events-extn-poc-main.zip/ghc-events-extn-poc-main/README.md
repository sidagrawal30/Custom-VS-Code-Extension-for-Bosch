# ghc-events-extn-poc
PoC project to prove out VSCode event handling for GitHub Copilot interaction
