// Get the form element by its ID
console.log('submitForm.js loaded');
const form = document.getElementById('surveyForm');
// Adding event listener for form submission
form.addEventListener('submit', (event) => {
    console.log('Form submitted');
    // Prevent default form submission
    event.preventDefault();
    // Send message to extension
    vscode.postMessage({ type: 'formSubmitted' });
});
