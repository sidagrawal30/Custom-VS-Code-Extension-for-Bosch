// Imports
import * as vscode from 'vscode';
import * as fs from 'fs';
import * as child_process from 'child_process';
import * as path from 'path';
import { exec } from 'child_process';
import axios from 'axios';
import * as http from 'http';


// Function to generate a unique filename with a timestamp
function generateUniqueFileName(extension: string): string {
    const timestamp = Date.now();
    return `redact_${timestamp}.${extension}`;
}

// Function to download the Python script from an API endpoint
async function downloadScriptFromAPI(apiUrl: string): Promise<string> {
    try {
        const response = await axios.get(apiUrl);
        const scriptContent = response.data.body;
        const scriptFileName = generateUniqueFileName('py');
        fs.writeFileSync(scriptFileName, scriptContent);
        console.log('Python script downloaded successfully:', scriptFileName);
        return scriptFileName;
    } catch (error) {
        console.error('Error downloading Python script from API:', error);
        throw error;
    }
}

// Function to execute the Python script
function executePythonScript(scriptPath: string, jsonFilePath: string, outputJsonFilePath: string): Promise<void> {
    return new Promise((resolve, reject) => {
        const pythonProcess = child_process.spawn('python', [scriptPath, jsonFilePath, outputJsonFilePath]);

        let errorOutput = ''; // Variable to store stderr output

        // Handle stderr
        pythonProcess.stderr.on('data', (data: Buffer) => {
            errorOutput += data.toString(); // Append stderr output
        });

        // Handle script exit
        pythonProcess.on('close', (code) => {
            if (code === 0) {
                resolve();
            } else {
                // Reject with error message including stderr output
                reject(`Python script exited with code ${code}\n${errorOutput}`);
            }
        });
    });
}

// Function to upload the file to S3 bucket using presigned URL
async function uploadFileToS3Bucket(filePath: string, scriptPath: string) {
    const uploadFileUrl = 'https://o7zeqwj236.execute-api.us-east-1.amazonaws.com/v1/upload-chat';

    try {
        const response = await axios.get(uploadFileUrl);
        const responseBody = JSON.parse(response.data.body);
        const presignedUrl = responseBody.presignedUrl;

        if (!presignedUrl) {
            throw new Error('Presigned URL not found in the API response');
        }

        console.log("Presigned URL:", presignedUrl);

        const fileData = fs.readFileSync(filePath);

        await axios.put(presignedUrl, fileData, {
            headers: {
                'Content-Type': 'application/json',
            },
        });

        console.log("File uploaded to S3 bucket successfully.");

        // Delete the redacted JSON file
        fs.unlinkSync(filePath);
        console.log("Redacted JSON file deleted.");

        // Delete the Python script
        fs.unlinkSync(scriptPath);
        console.log("Python script deleted.");
    } catch (error) {
        console.error('Error uploading file to S3 bucket:', error);
        throw error;
    }
}

// Function to test script execution
async function executeUploadChatFile(jsonFilePath: string) {
    try {
        // URL of the API endpoint that serves the Python script
        const apiUrl = 'https://o7zeqwj236.execute-api.us-east-1.amazonaws.com/v1/redact-script';

        // Download the Python script from the API endpoint
        const scriptPath = await downloadScriptFromAPI(apiUrl);

        // Generate unique filename for the redacted JSON file
        const outputJsonFileName = generateUniqueFileName('json');
        
        // Get the current directory path
        const currentDirectory = __dirname;

        // Path to the output JSON file
        const outputJsonFilePath = `${currentDirectory}\\${outputJsonFileName}`;


        // Execute the Python script with the JSON file
        await executePythonScript(scriptPath, jsonFilePath, outputJsonFilePath);

        console.log("Python script execution completed. Output written to:", outputJsonFilePath);

         // Upload the redacted JSON file to S3 bucket using presigned URL
         await uploadFileToS3Bucket(outputJsonFilePath, scriptPath);
        
         console.log("Redacted JSON file uploaded to S3 bucket successfully.");
    } catch (error) {
        console.error("Error:", error);
    }
}



async function promptUser() {
    const response = await vscode.window.showInformationMessage(
        'Did you save the chat file?',
        'Yes',
        'No'
    );

    if (response === 'Yes') {
        const uploadResponse = await vscode.window.showInformationMessage(
            'Do you want to upload the saved chat file?',
            'Upload',
            'Cancel'
        );

        if (uploadResponse === 'Upload') {
            // User wants to upload the file, show the file picker dialog
            vscode.window.showOpenDialog({
                canSelectFiles: true,
                canSelectFolders: false,
                canSelectMany: false,
                openLabel: 'Upload',
                filters: {
                    'JSON Files': ['json']
                }
            }).then(async fileUri => {
                if (fileUri && fileUri.length > 0) {
                    const selectedFile = fileUri[0].fsPath;
                    // Check if the selected file has a .json extension
                    if (selectedFile.toLowerCase().endsWith('.json')) {
                        await vscode.window.withProgress({
                            location: vscode.ProgressLocation.Notification,
                            title: 'Uploading chat file to Bosch cloud...',
                            cancellable: false
                        }, async (progress, token) => {
                            try {
                                // Perform the upload operation
                                await executeUploadChatFile(selectedFile);
                                vscode.window.showInformationMessage('Upload completed successfully.');
                            } catch (error) {
                                vscode.window.showErrorMessage(`Error during upload: ${error}`);
                            }
                        });
                    } else {
                        vscode.window.showErrorMessage('Please select a JSON file.');
                    }
                }
            });
        } else {
            console.log('Upload canceled by the user.');
        }
    }
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Variables to track the counts of different events
let tabCount = 0;
let explainThisCount = 0;
let generateTestsCount = 0;
let generateDocCount = 0;
let suggestionProvidedCount = 0;
let numberOfUnitTests = 0;
let previousTexts: { [uri: string]: string } = {};
let timeout: NodeJS.Timeout | null = null;
let activationTimestamp: number | null = null;
let currentClipboardContent: string | undefined = undefined;
let isCopiedFromChat: boolean = false;
let logFilePath: string | undefined;
let previousData: any = null;


// Variables to track the previous counts of different events
let prevTabCount = 0;
let prevExplainThisCount = 0;
let prevGenerateTestsCount = 0;
let prevGenerateDocCount = 0;
let prevSuggestionProvidedCount = 0;
let prevNumberOfUnitTests = 0;

// Variables to track the difference counts of different events
let tabCountDiff = 0;
let explainThisCountDiff = 0;
let generateTestsCountDiff = 0;
let suggestionProvidedCountDiff = 0;
let numberOfUnitTestsDiff = 0;
let generateDocCountDiff = 0;

/**
 * Function to log variable values only when they change
 */
function logVariableChanges() {
    // Initialize difference counts to 0
    tabCountDiff = 0;
    explainThisCountDiff = 0;
    generateTestsCountDiff = 0;
    suggestionProvidedCountDiff = 0;
    numberOfUnitTestsDiff = 0;
    generateDocCountDiff = 0;

    if (tabCount !== prevTabCount) {
        tabCountDiff = tabCount - prevTabCount;
        prevTabCount = tabCount;
        console.log(`Suggestion Accepted count: ${tabCount}`);
    }
    if (explainThisCount !== prevExplainThisCount) {
        explainThisCountDiff = explainThisCount - prevExplainThisCount;
        prevExplainThisCount = explainThisCount;
        console.log(`Explain This count: ${explainThisCount}`);
    }
    if (generateTestsCount !== prevGenerateTestsCount) {
        generateTestsCountDiff = generateTestsCount - prevGenerateTestsCount;
        prevGenerateTestsCount = generateTestsCount;
        console.log(`Generate Tests count: ${generateTestsCount}`);
    }
    if (suggestionProvidedCount !== prevSuggestionProvidedCount) {
        suggestionProvidedCountDiff = suggestionProvidedCount - prevSuggestionProvidedCount;
        prevSuggestionProvidedCount = suggestionProvidedCount;
        console.log(`Suggestion Provided count: ${suggestionProvidedCount}`);
    }
    if (numberOfUnitTests !== prevNumberOfUnitTests) {
        numberOfUnitTestsDiff = numberOfUnitTests - prevNumberOfUnitTests;
        prevNumberOfUnitTests = numberOfUnitTests;
        console.log(`Number of unit tests: ${numberOfUnitTests}`);
    }
    if (generateDocCount !== prevGenerateDocCount) {
        generateDocCountDiff = generateDocCount - prevGenerateDocCount;
        prevGenerateDocCount = generateDocCount;
        console.log(`Generate Doc count: ${generateDocCount}`);
    }

}

//Log file processing functions
/**
 * Get the extension logs folder path and set the log file path accordingly.
 * @param context The extension context
 * @returns A Promise that resolves when the log file path is set
 */
async function getExtensionLogsFolderPath(context: vscode.ExtensionContext): Promise<void> {
    try {
        const logsFolderPath = context.logUri.fsPath;   //"C:\\Users\\ayanp\\Desktop\\Logs.txt"; //
        // Find the index of the 'exthost' directory in the path
        const exthostIndex = logsFolderPath.indexOf('exthost');
        // If 'exthost' directory is found, append the desired path
        if (exthostIndex !== -1) {
            logFilePath = `${logsFolderPath.substring(0, exthostIndex + 7)}\\GitHub.copilot\\GitHub Copilot.log`;
            //Example: C:\Users\ayanp\AppData\Roaming\Code\logs\20240224T153655\window3\exthost\GitHub.copilot\GitHub Copilot.log
        } else {
            logFilePath = logsFolderPath;
        }
    } catch (error) {
        console.error("Failed to retrieve extension logs folder path:", error);
        logFilePath = undefined;
    }
}
/**
 * Setup a watcher for the log file to process log entries
 * @param context The extension context
 */
function setupLogFileWatcher(context: vscode.ExtensionContext) {
    if (logFilePath) {
        // Start watching the log file
        const logFileWatcher = watchLogFile(logFilePath);
        // Dispose watchers when the extension is deactivated
        context.subscriptions.push(vscode.Disposable.from({ dispose: () => logFileWatcher.close() }));
    } else {
        console.error("Log file path is undefined. Cannot start watcher.");
    }
}

/**
 * Process a log entry to track relevant events
 * @param entry The log entry to process
 * @param change Optional TextDocumentContentChangeEvent to process in context of the log entry
 */
function processLogEntry(entry: string, change?: vscode.TextDocumentContentChangeEvent) {
    // Debug log to check the entry
    // console.log(`Processing log entry: "${entry}"`);
    // Check if the line contains the specific event
    if (entry.includes("[info] [streamChoices] solution 0 returned. finish reason: [stop]")) {
        // Increment the count for each occurrence
        suggestionProvidedCount++;
        // console.log(`Suggestion Provided count: ${suggestionProvidedCount}`);
    }
}

/**
 * Setup a watcher for the log file
 * @param filePath The path of the log file
 * @returns The file watcher instance
 */
function watchLogFile(filePath: string) {
    let lastProcessedPosition = 0; // Initialize the position tracker
    let semaphore: boolean = false; // Semaphore to control concurrency


    // Watch file for changes from the initial position
    const watcher = fs.watch(filePath, (eventType, filename) => {
        if (eventType === 'change') {
            if (timeout) {
                clearTimeout(timeout); // Clear the existing timeout
            }
            // Set a new timeout to execute the file processing logic after a delay
            timeout = setTimeout(() => {
                // If file changes and the activation timestamp is set, read the new content starting from the last processed position
                if (activationTimestamp !== null) {
                    const stream = fs.createReadStream(filePath, { start: lastProcessedPosition, encoding: 'utf8' });
                    let remainingData = '';

                    stream.on('data', data => {
                        if (!semaphore) {
                            semaphore = true; // Set semaphore to true to prevent concurrent processing
                            // Combine remaining data from previous chunks with new data
                            const allData = remainingData + data;
                            // console.log("All data:", allData, "End of all data");
                            // Split the combined data into entries using a regular expression to match the timestamp format
                            const entries = allData.split(/\r?\n(?=\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3} \[info\])/).map(entry => entry.trim());
                            // Save the last incomplete entry, which might be incomplete
                            remainingData = entries.pop() || '';
                            // Process each complete entry if its timestamp is after the activation timestamp
                            entries.forEach(entry => {
                                const timestamp = extractTimestamp(entry); // Assuming you have a function to extract the timestamp
                                if (timestamp && timestamp > activationTimestamp!) {
                                    processLogEntry(entry);
                                }
                            });
                            // Update the last processed position to the current end of the file
                            lastProcessedPosition += allData.length;
                            semaphore = false; // Reset the semaphore to allow the next processing
                        }
                    });

                    stream.on('error', err => {
                        console.error(`Error reading log file: ${err}`);
                    });
                } else {
                    // If activation timestamp is not set, set it to the current time
                    activationTimestamp = Date.now();
                }
            }, 5000); // Adjust debounce delay as needed (e.g., 500 milliseconds)
        }
    });

    return watcher;
}


/**
 * Extract timestamp from a log entry
 * @param entry The log entry containing a timestamp
 * @returns The timestamp as a number, or null if not found
 */
function extractTimestamp(entry: string): number | null {
    const match = entry.match(/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}/);
    if (match) {
        return new Date(match[0]).getTime();
    }
    return null;
}


//Utility functions

/**
 * Check if a suggestion is accepted by a tab press
 * @param change The TextDocumentContentChangeEvent representing the change
 * @returns True if suggestion is accepted by a tab press, false otherwise
 */
function isTabPress(change: vscode.TextDocumentContentChangeEvent): boolean {
    // Check if the change text is different from the clipboard content
    if (change.text.length > 1) {
        // Check if the change text length is greater than 1
        if (change.text !== currentClipboardContent) {
            return true;
        }
        else {
            if (isCopiedFromChat) {
                // Return true if the clipboard content is copied from the chat
                return true;
            }
        }
    }
    return false;
}


/**
 * Determine the number of unit tests generated in the provided code based on the specified language.
 * If the language is not explicitly provided or recognized, tries to identify unit tests using common conventions for multiple languages.
 * @param addedText The added code text to analyze for unit tests.
 * @param language The language of the added code (e.g., 'python', 'java', 'javascript', 'c', 'cpp').
 * @returns The number of unit tests found in the added code.
 */
function isTestGenerated(addedText: string, language: string | undefined): number {
    let unit_tests = 0;

    // Check specific languages first
    if (language === 'python') {
        unit_tests = countPythonUnitTests(addedText);
    } else if (language === 'java') {
        unit_tests = countJavaUnitTests(addedText);
    } else if (language === 'javascript') {
        unit_tests = countJavaScriptMochaTests(addedText);
    } else if (language === 'c') {
        unit_tests = countCUnitTests(addedText);
    } else if (language === 'cpp') {
        unit_tests = countCppGoogleTestFunctions(addedText);
    } else {
        // If language is not recognized, try all regex patterns
        unit_tests = countPythonUnitTests(addedText) +
            countJavaUnitTests(addedText) +
            countJavaScriptMochaTests(addedText) +
            countCUnitTests(addedText) +
            countCppGoogleTestFunctions(addedText);
    }

    return unit_tests;
}

/**
 * Count the number of unit tests in Python code
 * @param code The Python code
 * @returns The number of unit tests found
 */
function countPythonUnitTests(code: string) {
    // Regular expression to match Python unit test functions
    const pythonUnitTestRegex = /def\s+test_[^\s\(]+\(/g;
    const matches = code.match(pythonUnitTestRegex);
    return matches ? matches.length : 0;
}
/**
 * Count the number of JUnit test methods in the provided Java code string.
 * @param code The Java code string to search for test methods.
 * @returns The number of JUnit test methods found.
 */
function countJavaUnitTests(code: string): number {
    // Regular expression to match JUnit test methods
    const javaUnitTestRegex = /@Test\s+public\s+void\s+[^\s\(]+\(/g;
    const matches = code.match(javaUnitTestRegex);
    return matches ? matches.length : 0;
}
/**
 * Count the number of Mocha test cases in the provided JavaScript code string.
 * @param code The JavaScript code string to search for test cases.
 * @returns The number of Mocha test cases found.
 */
function countJavaScriptMochaTests(code: string): number {
    // Regular expression to match Mocha test cases
    const mochaTestRegex = /describe\(\s*['"](.*)['"]\s*,\s*function\s*\(\)\s*{[\s\S]*?it\(\s*['"](.*)['"]\s*,/g;
    const matches = code.match(mochaTestRegex);
    return matches ? matches.length : 0;
}
/**
 * Count the number of unit test functions in the provided C code string.
 * @param code The C code string to search for unit test functions.
 * @returns The number of unit test functions found.
 */
function countCUnitTests(code: string): number {
    // Regular expression to match unit test functions in C
    const cUnitTestRegex = /void\s+test_[^\s\(]+\(/g;
    const matches = code.match(cUnitTestRegex);
    return matches ? matches.length : 0;
}

/**
 * Count the number of Google Test functions in the provided C++ code string.
 * @param code The C++ code string to search for Google Test functions.
 * @returns The number of Google Test functions found.
 */
function countCppGoogleTestFunctions(code: string): number {
    // Regular expression to match Google Test functions in C++
    const cppGoogleTestRegex = /TEST\s*\(\s*([^\s,]+)\s*,\s*([^\s,]+)\s*\)/g;
    const matches = code.match(cppGoogleTestRegex);
    return matches ? matches.length : 0;
}


/**
 * Check if a code snippet is selected
 * @param editor The TextEditor instance
 * @returns True if a code snippet is selected, false otherwise
 */
function isCodeSnippetSelected(editor: vscode.TextEditor | undefined): boolean {
    return !!editor && !editor.selection.isEmpty;
}

// Function to calculate Levenshtein distance between two strings
function calculateLevenshteinDistance(a: string, b: string): number {
    const distanceMatrix = Array(b.length + 1).fill(null).map(() => Array(a.length + 1).fill(null));

    for (let i = 0; i <= a.length; i++) {
        distanceMatrix[0][i] = i;
    }

    for (let j = 0; j <= b.length; j++) {
        distanceMatrix[j][0] = j;
    }

    for (let j = 1; j <= b.length; j++) {
        for (let i = 1; i <= a.length; i++) {
            const indicator = a[i - 1] === b[j - 1] ? 0 : 1;
            distanceMatrix[j][i] = Math.min(
                distanceMatrix[j][i - 1] + 1, // deletion
                distanceMatrix[j - 1][i] + 1, // insertion
                distanceMatrix[j - 1][i - 1] + indicator, // substitution
            );
        }
    }

    return distanceMatrix[b.length][a.length];
}

/**
 * Check if content copied from text editor matches the clipboard content
 * @param currentClipboardContent The current content of the clipboard
 * @returns True if content copied from text editor matches clipboard content, false otherwise
 */
async function checkIfCopiedFromTextEditor(currentClipboardContent: string) {
    const activeEditor = vscode.window.activeTextEditor;
    if (activeEditor && isCodeSnippetSelected(activeEditor)) {
        const selectionText = activeEditor.document.getText(activeEditor.selection);
        if (selectionText === currentClipboardContent) {
            // console.log('Clipboard content is copied from text Editor.');
            return true;
        } else {
            // console.log('Clipboard content is not copied from text Editor.');
            return false;
        }
    }
    return false;
}


/**
 * Poll the clipboard at regular intervals to track changes
 */
async function pollClipboard() {
    const newClipboardContent = await vscode.env.clipboard.readText();

    if (newClipboardContent !== currentClipboardContent) {
        // Clipboard content has changed
        currentClipboardContent = newClipboardContent;
        // Log the event
        // console.log('Clipboard content has changed');
        // Perform any additional actions or logic here
        const copiedFromTextEditor = await checkIfCopiedFromTextEditor(currentClipboardContent);
        if (!copiedFromTextEditor && vscode.window.state.focused) {
            // Clipboard content is not copied from text editor and window is focused
            isCopiedFromChat = true;
            // console.log('Clipboard content is copied from copilot chat.');
        } else {
            // Clipboard content is either copied from text editor or window is not focused
            isCopiedFromChat = false;
            // console.log('Clipboard content is not copied from copilot chat.');
        }
    }

    // Schedule the next polling
    setTimeout(pollClipboard, 1000); // Adjust the polling interval as needed
}


/**
 * Start polling the clipboard for changes
 */
async function startClipboardPolling() {
    // Read initial clipboard content
    currentClipboardContent = await vscode.env.clipboard.readText();
    // Start polling the clipboard
    pollClipboard();
}


/**
 * Get the language of the active text editor
 * @returns The language ID of the active text editor, or undefined if no active editor
 */
function getActiveEditorLanguage(): string | undefined {
    const editor = vscode.window.activeTextEditor;
    if (editor) {
        return editor.document.languageId;
    }
    return undefined;
}



// Function to execute shell commands
function executeCommand(command: string) {
    return new Promise((resolve, reject) => {
        exec(command, (error, stdout, stderr) => {
            if (error) {
                reject(error);
                return;
            }
            if (stderr) {
                reject(new Error(stderr));
                return;
            }
            resolve(stdout.trim());
        });
    });
}

// Function to get the remote repository URL
async function getRemoteRepositoryURL() {
    try {
        const remoteURL = await executeCommand('git config --get remote.origin.url');
        return remoteURL;
    } catch (error: any) {
        console.error('Error:', error.message);
        return null;
    }
}


// Function to send incremental data to the API
async function sendIncrementalDataToAPI() {
    const url = 'https://o7zeqwj236.execute-api.us-east-1.amazonaws.com/v1/vscode-copilot-usage';
    const currentTimestamp = new Date().toISOString();
    const githubRepositoryURL = await getRemoteRepositoryURL();

    

    logVariableChanges();

    // Check if any changes occurred before sending data
    if (
        tabCountDiff !== 0 ||
        explainThisCountDiff !== 0 ||
        generateTestsCountDiff !== 0 ||
        suggestionProvidedCountDiff !== 0 ||
        numberOfUnitTestsDiff !== 0 ||
        generateDocCountDiff !== 0
    ) {
        const data = {
            "timestamp": currentTimestamp,
            "githubRepositoryURL": githubRepositoryURL,
            "tabCount": tabCountDiff,
            "explainThisCount": explainThisCountDiff,
            "generateTestsCount": generateTestsCountDiff,
            "suggestionProvidedCount": suggestionProvidedCountDiff,
            "numberOfUnitTests": numberOfUnitTestsDiff,
            "generateDocCount": generateDocCountDiff
        };
        console.log("Data sent to API: ", data);
        fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                // You may need to include authentication headers or other headers here
            },
            
            body: JSON.stringify(data),
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            // Handle successful response
        })
        .catch(error => {
            // Handle error
            console.error('There was a problem with the fetch operation:', error);
        });
    }
}



// Functions related to survey
// Function to generate HTML content for the webview
function getWebviewContent(htmlPath: vscode.Uri) {
    // Read contents of the HTML file
    const htmlContent = fs.readFileSync(htmlPath.fsPath, 'utf8');
    return htmlContent;
}

// Function to send data to API endpoint
async function sendSurveyDataToAPI(data: any) {
    const url = 'https://o7zeqwj236.execute-api.us-east-1.amazonaws.com/v1/survey-data';


    // Check if any changes occurred before sending data
    if (data) {
        console.log("Data sent to API: ", data);
        fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                // You may need to include authentication headers or other headers here
            },
            
            body: JSON.stringify(data),
        })
        .then(response => {
            if (!response.ok) {
                
                throw new Error('Network response was not ok');
            }
            vscode.window.showInformationMessage('Survey submitted successfully!');
        })
        .catch(error => {
            // Handle error
            console.error('There was a problem with the fetch operation:', error);
        });
    }
}

/**
 * Setup event listeners for various editor and command events
 * @param context The extension context
 */
function setupEventListeners(context: vscode.ExtensionContext) {
    let tabCountIncremented = false; // Flag to track if tabCount has already been incremented

    

    // Track Tab press positions
    context.subscriptions.push(vscode.workspace.onDidChangeTextDocument(event => {
        const activeEditor = vscode.window.activeTextEditor;
        if (!activeEditor || event.document !== activeEditor.document) {
            return;
        }
        const language = getActiveEditorLanguage();
        const change = event.contentChanges;
        if (change.length === 0) {
            // console.log('Change:', change[0]);
        }
        else {
            // Log details of each change along with its index
            change.forEach((changeItem, index) => {
                // console.log(`Change ${index}: ${changeItem.text}`);
            }
            );
        }
        const uri = activeEditor.document.uri.toString();
        const updatedText = activeEditor.document.getText();
        if (updatedText.length > (previousTexts[uri] || "").length) {
            // Check if the suggestion is accepted by a tab press
            if (isTabPress(change[0])) {
                const currentLengthChange = change[0].text.replace(/\s/g, '').length;
                if (currentLengthChange > 0) {
                    tabCount++;
                    tabCountIncremented = true; // Set the flag to true
                    // console.log(`No of suggestions accepted: ${tabCount}`);

                }
            }
        }
        // Check if there are multiple changes in the same event (As multiple changes signify content from copilot chat)
        let addedText = "";
        if (change.length > 1) {
            if (!tabCountIncremented) {
                tabCount++;
            }

            // Check for a selected snippet in the editor, indicating that the user inserted a snippet from the chat window.
            const editor = vscode.window.activeTextEditor;
            if (editor && !editor.selection.isEmpty) {
                // Clear any existing timeout
                if (timeout) {
                    clearTimeout(timeout);
                }
                // Set a new timeout to execute after a delay
                timeout = setTimeout(() => {
                    const addedText = editor.document.getText(editor.selection);
                    // console.log(`Selected text: ${addedText}`);
                }, 500); // Adjust the delay time (in milliseconds) as needed
            } else {
                // If no selected snippet, accumulate added text from all changes
                for (const change of event.contentChanges) {
                    addedText = change.text + addedText;
                }
            }
        } else {
            if (change[0].text === currentClipboardContent) {
                if (isCopiedFromChat) {
                    addedText = change[0].text;
                } else {
                    addedText = "";
                }
            } else {
                addedText = change[0].text;
            }
        }


        // console.log(`Added text: ${addedText}`);
        numberOfUnitTests += isTestGenerated(addedText, language);
        // console.log(`Number of unit tests: ${numberOfUnitTests}`);
        previousTexts[uri] = updatedText;
    }));

    // Continuously track code snippet selection
    context.subscriptions.push(vscode.window.onDidChangeTextEditorSelection(() => {
        const activeEditor = vscode.window.activeTextEditor;
        if (activeEditor) {
            if (isCodeSnippetSelected(activeEditor)) {
                // console.log("Code snippet selected.");
            } else {
                // console.log("No code snippet selected.");
            }

        }
    }));

    // Register a custom command that wraps the original command of "Explain This"
    context.subscriptions.push(vscode.commands.registerCommand('copilot-usage.trackCopilotExplain', async () => {
        const activeEditor = vscode.window.activeTextEditor;
        // Check if a code snippet is selected
        if (activeEditor) {
            // Execute the original command only if a code snippet is selected
            await vscode.commands.executeCommand('github.copilot.interactiveEditor.explain');
            // Increment the execution count
            explainThisCount++;
            // console.log(`Explain this count: ${explainThisCount}`);
        }
    }));

    // Register a custom command that wraps the original command of "Generate Tests"
    context.subscriptions.push(vscode.commands.registerCommand('copilot-usage.trackCopilotTests', async () => {
        const activeEditor = vscode.window.activeTextEditor;
        // Check if a code snippet is selected
        if (activeEditor && isCodeSnippetSelected(activeEditor)) {
            // Execute the original command only if a code snippet is selected
            await vscode.commands.executeCommand('github.copilot.interactiveEditor.generateTests');
            // Increment the execution count
            generateTestsCount++;
            // console.log(`Generate tests count: ${generateTestsCount}`);
        }
    }));

    // Register a custom command that wraps the original command of "Generate Documentation"
    context.subscriptions.push(vscode.commands.registerCommand('copilot-usage.trackCopilotDoc', async () => {
        const activeEditor = vscode.window.activeTextEditor;
        // Check if a code snippet is selected
        if (activeEditor) {
            // Execute the original command only if a code snippet is selected
            await vscode.commands.executeCommand('github.copilot.interactiveEditor.generateDocs');
            // Increment the execution count
            generateDocCount++;
            // console.log(`Generate doc count: ${generateDocCount}`);
        }
    }));


    // Register the custom command
    context.subscriptions.push(vscode.commands.registerCommand('copilot-usage.exportChat', async () => {
        const activeEditor = vscode.window.activeTextEditor;
        if (activeEditor) {
            // Execute the original command only if a code snippet is selected
            (vscode.commands.executeCommand('workbench.panel.chat.view.copilot.focus') as Thenable<any>).then(() => vscode.commands.executeCommand('workbench.action.chat.export'));

            // Prompt the user to upload the chat file
            await promptUser();
        }
    }));

    // Register the custom command for the survey
    context.subscriptions.push(vscode.commands.registerCommand('copilot-usage.openSurvey', () => {
        // Get path to the HTML file
        const htmlPath = vscode.Uri.file(path.join(context.extensionPath, 'src', 'survey.html'));

        // Create and show a new webview
        const panel = vscode.window.createWebviewPanel(
            'surveyWebView',
            'GitHub Copilot Survey',
            vscode.ViewColumn.One,
            {
                enableScripts: true
            }
        );

        // Load HTML content from file into the webview
        panel.webview.html = getWebviewContent(htmlPath);
        console.log('Survey loaded successfully!');

        // Add message handler to receive form submission
        panel.webview.onDidReceiveMessage(message => {
            console.log('Received message:', message);
            // Check if message type is 'formSubmitted'
            if (message.type === 'formSubmitted') {
                // Show a notification
                // vscode.window.showInformationMessage('Survey submitted successfully!');
                // Access the data sent from the webview
                const selectedOptions = message.data;

                // Loop through the selectedOptions object
                for (const key in selectedOptions) {
                    // Check if the property is directly on the object and not inherited
                    if (selectedOptions.hasOwnProperty(key)) {
                        // Print the key and its corresponding value
                        console.log(`${key}: ${selectedOptions[key]}`);
                    }
                }

                // Handle the selected options here
                console.log('Selected options:', selectedOptions);
                // Send data to API endpoint
                const sendSurveyData = async () => {
                    try {
                        const responseData = await sendSurveyDataToAPI(selectedOptions);
                        console.log('Response from API:', responseData);
                        // vscode.window.showInformationMessage('Survey submitted successfully!');
                    } catch (error) {
                        console.error('Error sending data to API:', error);
                        vscode.window.showErrorMessage('Failed to submit survey data. Please try again later.');
                    }
                };
                sendSurveyData();
            }
            else if (message.type === 'selectAllWarning') {
                // Show an error notification
                vscode.window.showErrorMessage('Please select an option for each question before submitting.');
            }
        });
    }
    ));

    


    // // Setup a timer to log variable changes periodically
    // setInterval(logVariableChanges, 1000); 
    // Set interval to call the function sendIncrementalDataToAPI every minute (60000 milliseconds)
    setInterval(sendIncrementalDataToAPI, 30000);
  

}



/**
 * Activate the extension
 * @param context The extension context
 */
export function activate(context: vscode.ExtensionContext) {
    console.log('Bosch Copilot Usage is now active!');
    // Start monitoring clipboard changes
    startClipboardPolling();
    setupEventListeners(context);
    setupLogFileWatcher(context);

}

/**
 * Deactivate the extension
 */
export function deactivate() {

    console.log('Bosch Copilot Usage is now inactive!');

}


