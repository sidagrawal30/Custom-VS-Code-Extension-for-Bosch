import { on } from 'events';
import * as vscode from 'vscode';
export function activate(context: vscode.ExtensionContext) {
    console.log('Your extension "copilot-usage" is now active!');
    // Subscribe to all text document-related events
    context.subscriptions.push(
        vscode.workspace.onDidChangeTextDocument(event => {
            console.log('onDidChangeTextDocument', event);
        }),
        vscode.workspace.onDidOpenTextDocument(event => {
            console.log('onDidOpenTextDocument', event);
        }),
        vscode.workspace.onDidCloseTextDocument(event => {
            console.log('onDidCloseTextDocument', event);
        }),
        vscode.window.onDidChangeTextEditorSelection(event => {
            console.log('onDidChangeTextEditorSelection', event);
        }),
        vscode.window.onDidChangeTextEditorVisibleRanges(event => {
            console.log('onDidChangeTextEditorVisibleRanges', event);
        }),
        vscode.window.onDidChangeTextEditorOptions(event => {
            console.log('onDidChangeTextEditorOptions', event);
        }),
        vscode.window.onDidChangeTextEditorViewColumn(event => {
            console.log('onDidChangeTextEditorViewColumn', event);
        }),
        vscode.workspace.onDidSaveTextDocument(event => {
            console.log('onDidSaveTextDocument', event);
        }),
        vscode.workspace.onWillSaveTextDocument(event => {
            console.log('onWillSaveTextDocument', event);
        })
    );
}

