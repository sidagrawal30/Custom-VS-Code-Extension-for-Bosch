import streamlit as st
import json

# Function to clean text
def clean_text(text):
    return text.strip().replace('\r', '').replace('\n', '')

# Streamlit app
def main():
    st.title("Bosch Copilot Analysis")
    # Retrieve data from URL parameters
    query_params = st.experimental_get_query_params()
    if "data" in query_params:
        data = json.loads(query_params["data"][0])
        
        # Extract message text and chat response codes
        for request in data.get("requests", []):
            user_prompt = request.get("message", {}).get("text", "")
            st.subheader("User Prompt:")
            st.code(user_prompt)
            
            if "response" in request and request["response"]:
                response_code = request["response"][0].get("value")
                if response_code is not None:
                    st.subheader("Chat Response Code:")
                    response_language = request["response"][0].get("language", "plaintext")
                    st.code(response_code, language=response_language)
                else:
                    st.write("No chat response code available")
            else:
                st.write("No chat response")

            
            st.markdown("---")  # Separating each prompt and response

if __name__ == "__main__":
    # Assume `data` is already loaded from the JSON file in page 1
    main()
