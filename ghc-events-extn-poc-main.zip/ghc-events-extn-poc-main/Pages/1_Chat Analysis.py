import json
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import streamlit as st
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.decomposition import PCA
import pandas as pd
import plotly.express as px
from sklearn.cluster import DBSCAN
import sys
import chardet
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation
import string
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize


# Function to clean text
def clean_text(text):
    return text.strip().replace('\r', '').replace('\n', '')

# Function to generate WordCloud
def generate_wordcloud(text):
    wordcloud = WordCloud(width=600, height=600, 
                          background_color='white', 
                          stopwords=set(['s']),  # Any stopwords you'd like to exclude
                          min_font_size=10).generate(text)

    fig, ax = plt.subplots(figsize=(6, 6), facecolor=None)
    ax.imshow(wordcloud, interpolation='bilinear')
    ax.axis("off")
    plt.tight_layout(pad=0)
    st.pyplot(fig)

# Function to load data from command-line arguments
def load_data_from_args():
    if len(sys.argv) > 1:
        file_path = sys.argv[1]  # Get the file path from command-line arguments
        try:
            with open(file_path, 'rb') as file:  # Open the file in binary mode
                # Read a chunk of the file to detect its encoding
                raw_data = file.read(100000)  # Read first 100KB of the file
                encoding = chardet.detect(raw_data)['encoding']
            with open(file_path, 'r', encoding=encoding) as file:  # Reopen the file with detected encoding
                data = json.load(file)
            # Process the received data
            # st.write("Received data:", data)
            return data
        except Exception as e:
            st.error("Error loading data: " + str(e))  # Concatenate error message strings
            return None
    else:
        st.write("No file path received.")
        return None



def plot_3d_similarity(user_prompts):
    # Vectorize user prompts
    vectorizer = TfidfVectorizer()
    X = vectorizer.fit_transform(user_prompts)

    # Compute similarity matrix
    similarity_matrix = cosine_similarity(X)

    # Reduce dimensionality to 3 for plotting
    pca = PCA(n_components=3)
    pca_result = pca.fit_transform(similarity_matrix)

    # Perform clustering with DBSCAN
    dbscan = DBSCAN(eps=0.5, min_samples=2)  
    clusters = dbscan.fit_predict(pca_result)

    # Create DataFrame for plotting
    df = pd.DataFrame(pca_result, columns=["x", "y", "z"])
    df['cluster'] = clusters
    df['prompt'] = user_prompts

    # Plot 3D scatter plot with colored clusters
    fig = px.scatter_3d(df, x='x', y='y', z='z', color='cluster', hover_data={'prompt': True, 'cluster': False, 'x': False, 'y': False, 'z': False})
    fig.update_traces(hoverinfo='text')  # Show only user prompt on hover
    fig.update_traces(texttemplate='%{customdata}', textposition='top center')  # Customize hover tooltip
    st.plotly_chart(fig)
    fig.write_html("user_prompts_similarity.html")  # Save the plot as an HTML file



def clean_text1(text):
    # Lowercase the text
    text = text.lower()
    # Remove punctuation
    text = text.translate(str.maketrans('', '', string.punctuation))
    # Tokenize the text
    tokens = word_tokenize(text)
    # Remove stopwords
    stop_words = set(stopwords.words('english'))
    tokens = [word for word in tokens if word not in stop_words]
    # Join the tokens back into a single string
    cleaned_text = ' '.join(tokens)
    return cleaned_text

def lda_topic_modeling(user_prompts, num_topics=3, num_top_words=5):
    # Clean user prompts
    cleaned_user_prompts = [clean_text1(prompt) for prompt in user_prompts]

    # Vectorize user prompts using CountVectorizer
    vectorizer = CountVectorizer()
    X = vectorizer.fit_transform(cleaned_user_prompts)

    # Apply LDA
    lda = LatentDirichletAllocation(n_components=num_topics, random_state=42)
    lda.fit(X)

    # Display topics and associated words
    feature_names = vectorizer.get_feature_names_out()
    for topic_idx, topic in enumerate(lda.components_):
        st.write(f"Topic {topic_idx + 1}:")
        top_words_idx = topic.argsort()[:-num_top_words-1:-1]  # Get indices of top words for the topic
        top_words = [feature_names[i] for i in top_words_idx]
        st.write(", ".join(top_words))


# Streamlit app
def main():
    st.title("Bosch Copilot Analysis")


     # Load data from command-line arguments
    data = load_data_from_args()
    if data:
        
        # Set the query parameters to pass data to the next page
        st.experimental_set_query_params(data=json.dumps(data))

        user_prompts = []
        response_prompts = []
        # Extract message text and chat response codes
        for request in data["requests"]:
            user_prompts.append(clean_text(request["message"]["text"]))
            
            if "response" in request and request["response"]:
                response_text = request["response"][0].get("value")
                if response_text is not None:
                    response_prompts.append(clean_text(response_text))

        st.header("User Prompt Statistics")
        # Display User realted prompts information
        total_user_prompts = len(user_prompts)
        st.write(f"**Total User Prompts:** {total_user_prompts}")

        user_prompt_lengths = [len(prompt) for prompt in user_prompts]
        avg_user_prompt_length = sum(user_prompt_lengths) / len(user_prompt_lengths)
        st.write(f"**Average length of user prompts:** {int(avg_user_prompt_length)} characters")

        st.header("Response Prompt Statistics")
        # Display Response related prompts information
        total_response_prompts = len(response_prompts)
        st.write(f"**Total Response Prompts:** {total_response_prompts}")

        response_prompt_lengths = [len(prompt) for prompt in response_prompts]      
        avg_response_prompt_length = sum(response_prompt_lengths) / len(response_prompt_lengths)
        st.write(f"**Average length of response prompts:** {int(avg_response_prompt_length)} characters")

        # Concatenate cleaned prompts into a single string
        wordcloud_text = " ".join(user_prompts)
        # Generate and display WordCloud
        st.header("User Prompts Word Cloud")
        generate_wordcloud(wordcloud_text)

        
        # Concatenate cleaned prompts into a single string
        wordcloud_text = " ".join(response_prompts)
        # Generate and display WordCloud
        st.header("Chat Responses Word Cloud")
        generate_wordcloud(wordcloud_text)

        st.header("User Prompts Similarity")
        plot_3d_similarity(user_prompts)

        st.header("Chat Responses Similarity")
        plot_3d_similarity(response_prompts)

        st.header("Topics Extracted from User Prompts")
        lda_topic_modeling(user_prompts)

        st.header("Topics Extracted from Response Prompts")
        lda_topic_modeling(response_prompts)


    else:
        st.write("No data received.")


if __name__ == "__main__":
    main()
