import streamlit as st

# Set Streamlit page configuration
st.set_page_config(
    page_title="Bosch Copilot Analysis",
    page_icon="👋",
)

# Main title
st.write("# Bosch Copilot Chat Analysis 👋")

# Sidebar instructions
st.sidebar.success("Select a module above.")

# Instructions on how to navigate the application
st.write("## Instructions to Navigate the Application:")
st.write("1. Use the sidebar on the left to select a module.")
st.write("2. Once a module is selected, follow the instructions provided on the page.")
st.write("3. Explore the different features and functionalities available.")
st.write("4. Have a great experience with our Chat Analysis!")

# Additional information or tips can be added as needed
# Prepare a request body to github copilot chat endpoint
# request_body = {
#     "message": {
#         "text": "I want to book a flight to Paris"
#     }
# }
#
# # Send the request to the chat endpoint
# response = requests.post("https://api.githubcopilot.com/chat", json=request_body)
# if response.status_code == 200:
#     chat_response = response.json()
#     print(chat_response)
# else:
#     print("Error:", response.status_code)


