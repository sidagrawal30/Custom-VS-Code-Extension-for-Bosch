import json
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import streamlit as st
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.decomposition import PCA
import pandas as pd
import plotly.express as px
import sys
import chardet
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from sklearn.cluster import DBSCAN



# Define custom list of programming keywords
programming_keywords = {
    'python': {'and', 'as', 'assert', 'break', 'class', 'continue', 'def', 'del', 'elif', 'else', 'except', 'finally', 'for', 'from', 'global', 'if', 'import', 'in', 'is', 'lambda', 'nonlocal', 'not', 'or', 'pass', 'raise', 'return', 'try', 'while', 'with', 'yield'},
    'java': {'abstract', 'assert', 'boolean', 'break', 'byte', 'case', 'catch', 'char', 'class', 'continue', 'default', 'do', 'double', 'else', 'enum', 'extends', 'final', 'finally', 'float', 'for', 'if', 'implements', 'import', 'instanceof', 'int', 'interface', 'long', 'native', 'new', 'null', 'package', 'private', 'protected', 'public', 'return', 'short', 'static', 'strictfp', 'super', 'switch', 'synchronized', 'this', 'throw', 'throws', 'transient', 'try', 'void', 'volatile', 'while'},
    'c': {'auto', 'break', 'case', 'char', 'const', 'continue', 'default', 'do', 'double', 'else', 'enum', 'extern', 'float', 'for', 'goto', 'if', 'inline', 'int', 'long', 'register', 'restrict', 'return', 'short', 'signed', 'sizeof', 'static', 'struct', 'switch', 'typedef', 'union', 'unsigned', 'void', 'volatile', 'while'},
    'c#': {'abstract', 'as', 'base', 'bool', 'break', 'byte', 'case', 'catch', 'char', 'checked', 'class', 'const', 'continue', 'decimal', 'default', 'delegate', 'do', 'double', 'else', 'enum', 'event', 'explicit', 'extern', 'false', 'finally', 'fixed', 'float', 'for', 'foreach', 'goto', 'if', 'implicit', 'in', 'int', 'interface', 'internal', 'is', 'lock', 'long', 'namespace', 'new', 'null', 'object', 'operator', 'out', 'override', 'params', 'private', 'protected', 'public', 'readonly', 'ref', 'return', 'sbyte', 'sealed', 'short', 'sizeof', 'stackalloc', 'static', 'string', 'struct', 'switch', 'this', 'throw', 'true', 'try', 'typeof', 'uint', 'ulong', 'unchecked', 'unsafe', 'ushort', 'using', 'var', 'virtual', 'void', 'volatile', 'while'}
}

# Combine all programming keywords into a single set
all_keywords = set()
for lang_keywords in programming_keywords.values():
    all_keywords.update(lang_keywords)

# Get default English stopwords
english_stopwords = set(stopwords.words('english'))

# Remove programming keywords from stopwords
custom_stopwords = english_stopwords - all_keywords

def remove_stop_words_without_keywords(text):
     # Tokenize the text
    words = word_tokenize(text)
    
    # Remove stopwords
    filtered_words = [word for word in words if word.lower() not in custom_stopwords]
    
    # Join the filtered words back into a single string
    filtered_text = ' '.join(filtered_words)
    
    return filtered_text

def remove_stop_words(text):
    # Get default English stopwords
    english_stopwords = set(stopwords.words('english'))

    # Tokenize the text
    words = word_tokenize(text)
    
    # Remove stopwords
    filtered_words = [word for word in words if word.lower() not in english_stopwords]
    
    # Join the filtered words back into a single string
    filtered_text = ' '.join(filtered_words)
    
    return filtered_text

# Function to generate WordCloud
def generate_wordcloud(text):
    wordcloud = WordCloud(width=600, height=600, 
                          background_color='white', 
                          stopwords=set(['s']),  # Any stopwords you'd like to exclude
                          min_font_size=10).generate(text)

    fig, ax = plt.subplots(figsize=(6, 6), facecolor=None)
    ax.imshow(wordcloud, interpolation='bilinear')
    ax.axis("off")
    plt.tight_layout(pad=0)
    st.pyplot(fig)

# Function to load data from command-line arguments
def load_data_from_args():
    if len(sys.argv) > 1:
        file_path = sys.argv[1]  # Get the file path from command-line arguments
        try:
            with open(file_path, 'rb') as file:  # Open the file in binary mode
                # Read a chunk of the file to detect its encoding
                raw_data = file.read(100000)  # Read first 100KB of the file
                encoding = chardet.detect(raw_data)['encoding']
            with open(file_path, 'r', encoding=encoding) as file:  # Reopen the file with detected encoding
                data = json.load(file)
            # Process the received data
            # st.write("Received data:", data)
            return data
        except Exception as e:
            st.error("Error loading data: " + str(e))  # Concatenate error message strings
            return None
    else:
        st.write("No file path received.")
        return None



def plot_3d_similarity_old(user_prompts, cleaned_user_prompts):
    # Vectorize user prompts
    vectorizer = TfidfVectorizer()
    X = vectorizer.fit_transform(cleaned_user_prompts)

    # Compute similarity matrix
    similarity_matrix = cosine_similarity(X)

    # Reduce dimensionality to 3 for plotting
    pca = PCA(n_components=3)
    pca_result = pca.fit_transform(similarity_matrix)

    # Perform clustering with DBSCAN
    dbscan = DBSCAN(eps=0.5, min_samples=2)  
    clusters = dbscan.fit_predict(pca_result)

    # Create DataFrame for plotting
    df = pd.DataFrame(pca_result, columns=["x", "y", "z"])
    df['cluster'] = clusters
    df['prompt'] = user_prompts

    # Plot 3D scatter plot with colored clusters
    fig = px.scatter_3d(df, x='x', y='y', z='z', color='cluster', hover_data={'prompt': True, 'cluster': False, 'x': False, 'y': False, 'z': False})
    # Customize hover tooltip to display uncleaned text
    fig.update_traces(hoverinfo='text', text=df['prompt']) 
    fig.update_traces(texttemplate='%{customdata}', textposition='top center')  # Customize hover tooltip
    st.plotly_chart(fig)



def lda_topic_modeling(user_prompts, num_topics=3, num_top_words=5):
    # Clean user prompts
    cleaned_user_prompts = [remove_stop_words_without_keywords(prompt) for prompt in user_prompts]

    # Vectorize user prompts using CountVectorizer
    vectorizer = CountVectorizer()
    X = vectorizer.fit_transform(cleaned_user_prompts)

    # Apply LDA
    lda = LatentDirichletAllocation(n_components=num_topics, random_state=42)
    lda.fit(X)

    # Display topics and associated words
    feature_names = vectorizer.get_feature_names_out()
    for topic_idx, topic in enumerate(lda.components_):
        st.write(f"Topic {topic_idx + 1}:")
        top_words_idx = topic.argsort()[:-num_top_words-1:-1]  # Get indices of top words for the topic
        top_words = [feature_names[i] for i in top_words_idx]
        st.write(", ".join(top_words))


# Streamlit app
def main():
    st.title("Bosch Copilot Analysis")


     # Load data from command-line arguments
    data = load_data_from_args()
    if data:
        
        # Set the query parameters to pass data to the next page
        st.experimental_set_query_params(data=json.dumps(data))

        user_prompts = []
        user_prompts_with_keywords = []
        user_prompts_without_keywords = []
        response_prompts = []
        response_prompts_with_keywords = []
        response_prompts_without_keywords = []
        # Extract message text and chat response codes
        for request in data["requests"]:
            user_prompts.append(request["message"]["text"])
            user_prompts_without_keywords.append(remove_stop_words(request["message"]["text"]))
            user_prompts_with_keywords.append(remove_stop_words_without_keywords(request["message"]["text"]))
            
            if "response" in request and request["response"]:
                response_text = request["response"][0].get("value")
                if response_text is not None:
                    response_prompts.append(response_text)
                    response_prompts_without_keywords.append(remove_stop_words(response_text))
                    response_prompts_with_keywords.append(remove_stop_words_without_keywords(response_text))

        st.header("User Prompt Statistics")
        # Display User realted prompts information
        total_user_prompts = len(user_prompts)
        st.write(f"**Total User Prompts:** {total_user_prompts}")

        user_prompt_lengths = [len(prompt) for prompt in user_prompts]
        avg_user_prompt_length = sum(user_prompt_lengths) / len(user_prompt_lengths)
        st.write(f"**Average length of user prompts:** {int(avg_user_prompt_length)} characters")

        st.header("Response Prompt Statistics")
        # Display Response related prompts information
        total_response_prompts = len(response_prompts)
        st.write(f"**Total Response Prompts:** {total_response_prompts}")

        response_prompt_lengths = [len(prompt) for prompt in response_prompts]      
        avg_response_prompt_length = sum(response_prompt_lengths) / len(response_prompt_lengths)
        st.write(f"**Average length of response prompts:** {int(avg_response_prompt_length)} characters")

        st.header("User Prompt Word Cloud")
        # Create a dropdown to select between options
        user_option = st.selectbox("Select User Prompt Word Cloud Type:", ["Without Keywords", "With Keywords"], key="user_prompt_word_cloud")
        # Display WordCloud based on the selected option for user prompts
        if user_option == "Without Keywords":
            # Concatenate cleaned prompts into a single string
            wordcloud_text = " ".join(user_prompts_without_keywords)
            generate_wordcloud(wordcloud_text)
        elif user_option == "With Keywords":
            # Concatenate cleaned prompts into a single string
            wordcloud_text = " ".join(user_prompts_with_keywords)
            generate_wordcloud(wordcloud_text)

        st.header("Response Prompt Word Cloud")
        # Create a dropdown to select between options
        response_option = st.selectbox("Select Response Prompt Word Cloud Type:", ["Without Keywords", "With Keywords"], key="response_prompt_word_cloud")
        # Display WordCloud based on the selected option for response prompts
        if response_option == "Without Keywords":
            # Concatenate cleaned prompts into a single string
            wordcloud_text = " ".join(response_prompts_without_keywords)
            generate_wordcloud(wordcloud_text)
        elif response_option == "With Keywords":
            # Concatenate cleaned prompts into a single string
            wordcloud_text = " ".join(response_prompts_with_keywords)
            generate_wordcloud(wordcloud_text)

         # Create a select box to choose between with and without keywords
        st.header("User Prompts Similarity")
        option = st.selectbox("Select user prompt similarity type:", ["Without Keywords", "With Keywords"], key="user_prompt_similarity")
        # Check the selected option and call the appropriate function
        if option == "Without Keywords":
            plot_3d_similarity_old(user_prompts, user_prompts_without_keywords)
        elif option == "With Keywords":
            plot_3d_similarity_old(user_prompts, user_prompts_with_keywords)

        st.header("Response Prompts Similarity")
        option = st.selectbox("Select user prompt similarity type:", ["Without Keywords", "With Keywords"], key="response_prompt_similarity")
        # Check the selected option and call the appropriate function
        if option == "Without Keywords":
            plot_3d_similarity_old(response_prompts, response_prompts_without_keywords)
        elif option == "With Keywords":
            plot_3d_similarity_old(response_prompts, response_prompts_with_keywords)

        st.header("Topics Extracted from User Prompts")
        option = st.selectbox("Select user prompt topic type:", ["Without Keywords", "With Keywords"], key="user_prompt_topic_modeling")
        # Check the selected option and call the appropriate function
        if option == "Without Keywords":
            lda_topic_modeling(user_prompts_without_keywords)
        elif option == "With Keywords":
            lda_topic_modeling(user_prompts_with_keywords)
        # lda_topic_modeling(user_prompts)

        st.header("Topics Extracted from Response Prompts")
        option = st.selectbox("Select Response prompt topic type:", ["Without Keywords", "With Keywords"], key="response_prompt_topic_modeling")
        # Check the selected option and call the appropriate function
        if option == "Without Keywords":
            lda_topic_modeling(response_prompts_without_keywords)
        elif option == "With Keywords":
            lda_topic_modeling(response_prompts_with_keywords)
    else:
        st.write("No data received.")


if __name__ == "__main__":
    main()



