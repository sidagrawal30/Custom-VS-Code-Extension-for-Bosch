# ghc-power-bi-analytics
Power BI analytics for GHC usage data
