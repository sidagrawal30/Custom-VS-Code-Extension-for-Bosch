import sys
import json
import re
import spacy
import chardet

# Load English language model in spaCy
nlp = spacy.load("en_core_web_sm")

def redact_personal_info(text):
    # Tokenize the input text using spaCy
    doc = nlp(text)
    
    redacted_text = text
    
    # Redact names
    for ent in doc.ents:
        if ent.label_ == 'PERSON':
            redacted_text = redacted_text.replace(ent.text, "[REDACTED]")
    
    # Redact email addresses
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    redacted_text = re.sub(email_pattern, "[REDACTED_EMAIL]", redacted_text)
    
    return redacted_text

def redact_data(json_file_path):
    try:
        # Detect encoding of the input JSON file
        with open(json_file_path, 'rb') as f:
            raw_data = f.read()
            encoding = chardet.detect(raw_data)['encoding']
        
        # Read JSON data from file with detected encoding
        with open(json_file_path, 'r', encoding=encoding) as file:
            json_data = json.load(file)
        
        # Process JSON data (example: redact sensitive information)
        redacted_data = []
        for request in json_data.get("requests", []):
            redacted_request = {}
            # Redact message text
            request_text = request.get("message", {}).get("text")
            if request_text:
                redacted_request["redacted_request"] = redact_personal_info(request_text)

            # Redact response text
            response_text = None
            response_list = request.get("response", [])
            if response_list:
                response_text = response_list[0].get("value")
            if response_text:
                redacted_request["redacted_response"] = redact_personal_info(response_text)
                    
            redacted_data.append(redacted_request)
                
        return redacted_data
    except Exception as e:
        # Handle any errors gracefully
        print("Error:", e)
        return None

if __name__ == "__main__":
    # Check if JSON file path is provided as command-line argument
    if len(sys.argv) != 3:
        print("Usage: python script.py <input_json_file_path> <output_json_file_path>")
        sys.exit(1)
    
    input_json_file_path = sys.argv[1]
    output_json_file_path = sys.argv[2]
    
    # Redact data from JSON file
    redacted_data = redact_data(input_json_file_path)
    
    if redacted_data:
        try:
            # Open the output JSON file with UTF-8 encoding
            with open(output_json_file_path, 'w', encoding='utf-8') as outfile:
                json.dump(redacted_data, outfile, ensure_ascii=False, indent=4)
        except UnicodeEncodeError as e:
            # Handle UnicodeEncodeError
            print("UnicodeEncodeError:", e)
            # Attempt to write the data using utf-8 with errors='ignore' to skip characters that cannot be encoded
            with open(output_json_file_path, 'w', encoding='utf-8', errors='ignore') as outfile:
                json.dump(redacted_data, outfile, ensure_ascii=False, indent=4)
