# ghc-datalake-aws-stack
Repo for AWS data lake and analytics
